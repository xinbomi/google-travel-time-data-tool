"""
Tool:               <Travel Time Data Acquisition>
Source Name:        <Travel_Time.py>
Version:            <1.0>
Author:             <Xinbo Mi>
Usage:              <To obtain travel time data between Origin-Destination pairs>
Required Arguments: <OD paris and their GPS coordinates in 'OD Pairs_in.xlsx',
                    Starting and ending row indices in 'OD Pairs_in.xlsx' on Line 33 34,
                    Travel Time Estimation Date and Time on Line 38-42,
                    Your Own Organization's Google API key in 'API Key.text'>
Optional Arguments: <None>
Description:        <This tool extracts Google travel time data for pre-defined Origin-Destination pairs and
                    stores the data in an excel spreadsheet.>
Copyright:          <Copyright 2022 by Xinbo Mi. Feel free to share with others. No commercial use permitted.>
"""


# import .xlsx spreadsheet reading and writing module
from openpyxl import load_workbook
# import datetime module
import datetime
import time
from datetime import date
# import requests module to extract data from online url
import requests

# open input .xlsx file, which stores OD paris and their GPS coordinates
wb = load_workbook('OD Pairs_in.xlsx')
# open the worksheet
sheet = wb.active

# PLEASE SPECIFY WHICH ROW TO START AND WHICH ROW TO END IN THE INPUT SPREADSHEET
start_row_number = 3
end_row_number = 5  # Keep in mind: putting this number too high might use up all your organization's monthly free
# credits and start being charged!!! Read Google's billing policy first!!!

# PLEASE SPECIFY A FUTURE (it has to be future!!!) DATE AND TIME
year    = 2022
month   = 3
day    = 15
hour    = 16
minute  = 30

# get date and time from input
date_time = datetime.datetime(year, month, day, hour, minute)
# get day of week
weekday = date_time.strftime("%A")

# convert date and time to unix timestamp format
departure_time = time.mktime(date_time.timetuple())
departure_time = int(departure_time)

# Returns the current local date
today = date.today()

# access your organization's Google API key
# (don't forget to delete the key in "API Key.text" before sharing the tool package to others!!!)
API_file = open("API Key.txt","r")
API_key = API_file.readline()

# iterate through each row in the spreadsheet
for i in range(start_row_number, end_row_number+1):

    # get origin's and destination's GPS coordinates
    from_latitude = sheet['D'+str(i)].value
    from_longitude = sheet['E' + str(i)].value
    to_latitude = sheet['F' + str(i)].value
    to_longitude = sheet['G' + str(i)].value

    # generate main API url
    url = "https://maps.googleapis.com/maps/api/directions/json?origin="\
          + str(from_latitude)+","+str(from_longitude)+"&destination="+str(to_latitude)+","+str(to_longitude)\
          + "&departure_time="+str(departure_time)+"&key="+API_key

    # access the url to get the response
    payload = {}
    headers = {}
    response = requests.request("GET", url, headers=headers, data=payload)

    # access travel time data from the response
    response_json = response.json()
    duration = response_json['routes'][0]['legs'][0]['duration']['value']
    duration_in_traffic = response_json['routes'][0]['legs'][0]['duration_in_traffic']['value']

    # write output data to the output spreadsheet
    sheet['H' + str(i)] = str(date_time)
    sheet['I' + str(i)] = weekday
    sheet['J' + str(i)] = departure_time
    sheet['K' + str(i)] = duration
    sheet['L' + str(i)] = duration_in_traffic
    sheet['M' + str(i)] = today

    # optional to print, feel free to delete
    print(str(i))
    print(duration_in_traffic)

# save the output spreadsheet
wb.save('Travel Time_out.xlsx')
